<?php

$number = 5;
$string = strval($number);
$message = '';


switch(true){
    case str_contains($string, '1'):
        $message = "Number is 1";
        break;
    case str_contains($string, '2'):
        $message = "Number is 2";
        break;
    case str_contains($string, '3'):
        $message = "Number is 3";
        break;
    case str_contains($string, '4'):
        $message = "Number is 4";
        break;
    case str_contains($string, '5'):
        $message = "Bingo! Number is 5\nAnd 5*5 is " . ($number * $number);
        break;
}

if ($message !== '') {
    echo "$message\n";
    for ($i = 0; $i < $number; $i++) {
        echo "Loop iteration: $i\n";
    }
}

?>