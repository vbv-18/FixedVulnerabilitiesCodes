import sqlite3
from flask import Flask, request, render_template_string, jsonify, send_file, abort
import bcrypt
import os
import re
import magic

'''
Application to create users and download games of players
'''

app = Flask(__name__)

def validUsername(username):
    return re.fullmatch("[a-zA-Z0-9_]{1,10}", username) is not None

def is_valid_password(pwd):
    return re.fullmatch("(?=(.*\\d.*\\d))[a-zA-Z0-9_]{10,15}", pwd) is not None

def validGameId(game_id):
    return re.fullmatch("[a-zA-Z0-9_]{1,20}", game_id) is not None

def validFilename(filename):
    mime = magic.Magic(mime=True)
    return mime.from_file(filename) == "application/x-chess-pgn"

def create_user(username, password):
    hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt()) #se hashea la contraseña
    conn = sqlite3.connect(os.getenv("DB_NAME")) #se conecta con la bd
    cursor = conn.cursor()
    query = "INSERT INTO users (username, password) VALUES (?, ?)" #query para insertar el usuario y la contraseña
    cursor.execute(query, (username, hashed_password)) #segura por param parametrizados
    conn.commit()
    conn.close()

@app.route("/")
def index():
    user = request.args.get("id", "1")
    pwd = request.args.get("pwd", "")

    if is_valid_password(pwd) and validUsername(user):
        create_user(user,pwd)

    html_response = f""" ##no vulnerable porque no se incluyen parametros en la respuesta
    <h1>Thank you!</h1>
    <p></p>
    """
    return render_template_string(html_response)


@app.route("/downloadGames/<game_id>", methods=["GET"])
def download_games(game_id):
    if not validGameId(game_id):
        abort(400, "File not found")

    file_name = f"{game_id}.pgn"

    if not os.path.isfile(file_name) or not validFilename(file_name):
        abort(404, "File not found")

    return send_file(file_name, as_attachment=True)

if __name__ == "__main__":
    app.run(debug=False)