import java.io.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.logging.Level;
import java.util.logging.Logger;

public class VisitCounterFixed {
    private static final String FILE_NAME = "visit_count.txt";
    private static AtomicInteger count = new AtomicInteger(10);
    private static final Pattern INT_PATTERN = Pattern.compile("\\d+");
    private static final Logger LOGGER = Logger.getLogger(VisitCounterFixed.class.getName());

    // Simulate visit by incrementing the count

    private static boolean validateInput(String input){
        Matcher match = INT_PATTERN.matcher(input);
        return match.matches();
    }

    public static synchronized void incrementVisitCount() {
        // Read the current count from the file
        try(BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))){
            String line = reader.readLine();
            if(line != null && validateInput(line)){
                try{
                    count.set(Integer.parseInt(line));

                    // Increment the count
                    int newCount = count.incrementAndGet();

                    // Write the updated count back to the file
                    try(BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))){
                        writer.write(String.valueOf(newCount));
                        //writer.close();
                    }
                } catch(NumberFormatException e){
                    LOGGER.log(Level.WARNING, "Invalid number format", e);
                }
            }
            else{
                System.out.println("Invalid input");
            }
           
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error reading or writing file", e);
        }
    }

    public static void main(String[] args) throws InterruptedException, IOException {
        // Set the initial visit count to 0
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))){
            writer.write("0");
            //writer.close();
        }
        catch(IOException e){
            LOGGER.log(Level.SEVERE, "Error writing file", e);
            return;
        }
        ExecutorService executor = Executors.newFixedThreadPool(10);
        for (int i = 0; i < 1000; i++) {
            executor.submit(VisitCounterFixed::incrementVisitCount);
        }

        executor.shutdown();
        try {
            if (!executor.awaitTermination(1, TimeUnit.MINUTES)) {
                LOGGER.log(Level.WARNING, "Some threads did not finish");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); // Restaurar el estado de interrupción
            LOGGER.log(Level.SEVERE, "Thread interrupted", e);
        }
    }
}

