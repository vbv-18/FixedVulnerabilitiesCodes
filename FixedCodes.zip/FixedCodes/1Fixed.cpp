//
// Created by User on 07/02/2025.
//
#include <limits.h>
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>

int can_calculate(int width, int height){
    if (width > (INT_MAX/height) || height > (INT_MAX/width) || width < (INT_MIN/height) || height < (INT_MIN/width)){
        return 0;
    }
    return 1;
}


void calculate_area(int width, int height) {
    if (can_calculate(width, height)){
        int area = width * height;
        printf("Area: %d\n", area);
    }
    else{
        printf("La operacion excede los rangos permitidos\n");
    }
}

int main() {
    char buff[100];
    int ancho=0,alto=0, numInt=0;  // A large number
    printf("Calculadora del area de un rectangulo.\n");

    printf("Introduce el ancho.\n");
    scanf("%d",&ancho);

    printf("Introduce el alto.\n");
    scanf("%d",&alto);


    return 0;

}